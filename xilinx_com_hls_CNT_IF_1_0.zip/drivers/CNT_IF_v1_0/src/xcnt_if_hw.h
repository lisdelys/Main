// ==============================================================
// File generated on Wed Sep 11 17:23:37 EDT 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// H
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of s_Preload_H_V
//        bit 31~0 - s_Preload_H_V[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNT_IF_H_ADDR_S_PRELOAD_H_V_DATA 0x10
#define XCNT_IF_H_BITS_S_PRELOAD_H_V_DATA 32

// L
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of s_Preload_L_V
//        bit 31~0 - s_Preload_L_V[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNT_IF_L_ADDR_S_PRELOAD_L_V_DATA 0x10
#define XCNT_IF_L_BITS_S_PRELOAD_L_V_DATA 32

