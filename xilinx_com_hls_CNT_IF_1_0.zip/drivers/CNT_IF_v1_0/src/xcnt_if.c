// ==============================================================
// File generated on Wed Sep 11 17:23:37 EDT 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcnt_if.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCnt_if_CfgInitialize(XCnt_if *InstancePtr, XCnt_if_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->H_BaseAddress = ConfigPtr->H_BaseAddress;
    InstancePtr->L_BaseAddress = ConfigPtr->L_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCnt_if_Set_s_Preload_H_V(XCnt_if *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->H_BaseAddress, XCNT_IF_H_ADDR_S_PRELOAD_H_V_DATA, Data);
}

u32 XCnt_if_Get_s_Preload_H_V(XCnt_if *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->H_BaseAddress, XCNT_IF_H_ADDR_S_PRELOAD_H_V_DATA);
    return Data;
}

void XCnt_if_Set_s_Preload_L_V(XCnt_if *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->L_BaseAddress, XCNT_IF_L_ADDR_S_PRELOAD_L_V_DATA, Data);
}

u32 XCnt_if_Get_s_Preload_L_V(XCnt_if *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->L_BaseAddress, XCNT_IF_L_ADDR_S_PRELOAD_L_V_DATA);
    return Data;
}

