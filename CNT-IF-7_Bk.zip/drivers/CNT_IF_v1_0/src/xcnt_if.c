// ==============================================================
// File generated on Mon Sep 16 13:41:47 EDT 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcnt_if.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCnt_if_CfgInitialize(XCnt_if *InstancePtr, XCnt_if_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->M_ctrl_cntr_BaseAddress = ConfigPtr->M_ctrl_cntr_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCnt_if_Set_s_Compare_V(XCnt_if *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_COMPARE_V_DATA, (u32)(Data));
    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_COMPARE_V_DATA + 4, (u32)(Data >> 32));
}

u64 XCnt_if_Get_s_Compare_V(XCnt_if *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_COMPARE_V_DATA);
    Data += (u64)XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_COMPARE_V_DATA + 4) << 32;
    return Data;
}

void XCnt_if_Set_s_MASK_V(XCnt_if *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_MASK_V_DATA, (u32)(Data));
    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_MASK_V_DATA + 4, (u32)(Data >> 32));
}

u64 XCnt_if_Get_s_MASK_V(XCnt_if *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_MASK_V_DATA);
    Data += (u64)XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_MASK_V_DATA + 4) << 32;
    return Data;
}

void XCnt_if_Set_s_CLR(XCnt_if *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_CLR_DATA, Data);
}

u32 XCnt_if_Get_s_CLR(XCnt_if *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_CLR_DATA);
    return Data;
}

void XCnt_if_Set_s_SET(XCnt_if *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_SET_DATA, Data);
}

u32 XCnt_if_Get_s_SET(XCnt_if *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_SET_DATA);
    return Data;
}

void XCnt_if_Set_s_Load(XCnt_if *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_LOAD_DATA, Data);
}

u32 XCnt_if_Get_s_Load(XCnt_if *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_LOAD_DATA);
    return Data;
}

void XCnt_if_Set_s_Preload_V(XCnt_if *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_V_DATA, (u32)(Data));
    XCnt_if_WriteReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_V_DATA + 4, (u32)(Data >> 32));
}

u64 XCnt_if_Get_s_Preload_V(XCnt_if *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_V_DATA);
    Data += (u64)XCnt_if_ReadReg(InstancePtr->M_ctrl_cntr_BaseAddress, XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_V_DATA + 4) << 32;
    return Data;
}

