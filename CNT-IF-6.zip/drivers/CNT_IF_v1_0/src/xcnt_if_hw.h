// ==============================================================
// File generated on Thu Sep 12 16:54:29 EDT 2019
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// M_Ctrl_Cntr
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of s_Compare_V
//        bit 31~0 - s_Compare_V[31:0] (Read/Write)
// 0x14 : Data signal of s_Compare_V
//        bit 31~0 - s_Compare_V[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of s_MASK_V
//        bit 31~0 - s_MASK_V[31:0] (Read/Write)
// 0x20 : Data signal of s_MASK_V
//        bit 31~0 - s_MASK_V[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of s_CLR
//        bit 0  - s_CLR[0] (Read/Write)
//        others - reserved
// 0x2c : reserved
// 0x30 : Data signal of s_SET
//        bit 0  - s_SET[0] (Read/Write)
//        others - reserved
// 0x34 : reserved
// 0x38 : Data signal of s_Load
//        bit 0  - s_Load[0] (Read/Write)
//        others - reserved
// 0x3c : reserved
// 0x40 : Data signal of s_Preload_H_V
//        bit 31~0 - s_Preload_H_V[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of s_Preload_L_V
//        bit 31~0 - s_Preload_L_V[31:0] (Read/Write)
// 0x4c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCNT_IF_M_CTRL_CNTR_ADDR_S_COMPARE_V_DATA   0x10
#define XCNT_IF_M_CTRL_CNTR_BITS_S_COMPARE_V_DATA   64
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_MASK_V_DATA      0x1c
#define XCNT_IF_M_CTRL_CNTR_BITS_S_MASK_V_DATA      64
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_CLR_DATA         0x28
#define XCNT_IF_M_CTRL_CNTR_BITS_S_CLR_DATA         1
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_SET_DATA         0x30
#define XCNT_IF_M_CTRL_CNTR_BITS_S_SET_DATA         1
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_LOAD_DATA        0x38
#define XCNT_IF_M_CTRL_CNTR_BITS_S_LOAD_DATA        1
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_H_V_DATA 0x40
#define XCNT_IF_M_CTRL_CNTR_BITS_S_PRELOAD_H_V_DATA 32
#define XCNT_IF_M_CTRL_CNTR_ADDR_S_PRELOAD_L_V_DATA 0x48
#define XCNT_IF_M_CTRL_CNTR_BITS_S_PRELOAD_L_V_DATA 32

